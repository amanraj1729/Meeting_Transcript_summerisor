# Demo notebook (Python script format)
from pipeline import process_meeting
SAMPLE_1 = """
Meeting: Weekly Product Sync
Date: 2025-11-25
Attendees: Alice, Bob, Charlie

Alice: We need to finalize the UI for the dashboard by next Wednesday.
Bob: I'll take ownership of the dashboard charts.
Charlie: I will prepare the dataset and share it by Monday.
Decision: Use ChartLib v2 for visualization.
Action: Bob to implement charts by 2025-12-03. Charlie to share data by 2025-11-30.
"""
print(process_meeting(SAMPLE_1))
