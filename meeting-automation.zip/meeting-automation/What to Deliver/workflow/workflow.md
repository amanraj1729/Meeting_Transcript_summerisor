Workflow (input -> processing -> output)

1. Input: meeting transcript (text)
2. Preprocessing: normalize whitespace, replace unicode dashes
3. LLM: OpenRouter (gpt-4o-mini) called with TOOL spec to extract structured JSON
4. Validation: tolerant JSON parsing and schema checks
5. Postprocess: normalize action items, attendees
6. Output: structured JSON + summary
